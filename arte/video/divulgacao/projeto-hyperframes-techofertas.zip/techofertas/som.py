import numpy as np, wave
SR=48000; DUR=30.7; N=int(SR*DUR)
rng=np.random.default_rng(7)
def t(d): return np.arange(int(SR*d))/SR
def env(n, a=0.005, r=0.2):
    e=np.ones(n); na=max(1,int(SR*a)); e[:na]=np.linspace(0,1,na)
    e*=np.exp(-np.arange(n)/(SR*r)); return e
def add(buf, x, at, g=1.0):
    i=int(at*SR)
    if i>=len(buf): return
    j=min(len(buf), i+len(x)); buf[i:j]+=x[:j-i]*g
def sine(f,d): return np.sin(2*np.pi*f*t(d))
def ding(f=1318.5,d=0.9):
    x=(sine(f,d)+0.5*sine(f*2.01,d)+0.25*sine(f*3.0,d))*env(int(SR*d),0.002,0.25); return x/np.abs(x).max()
def notif():  # dois tons, estilo notificação de mensagem
    a=ding(1046.5,0.35)*0.8; b=ding(1568.0,0.6); x=np.zeros(int(SR*0.75)); x[:len(a)]+=a; x[int(SR*0.11):int(SR*0.11)+len(b)]+=b; return x/np.abs(x).max()
def whoosh(d=0.45, sobe=True):
    n=int(SR*d); r=rng.standard_normal(n); f=np.linspace(400,4000,n) if sobe else np.linspace(4000,400,n)
    y=np.zeros(n); a=0.0
    for k in range(n):  # passa-baixa variável simples
        c=np.exp(-2*np.pi*f[k]/SR); a=(1-c)*r[k]+c*a; y[k]=a
    e=np.sin(np.pi*np.linspace(0,1,n))**1.5; y=y*e; return y/np.abs(y).max()
def pop(f=600): x=sine(f,0.12)*env(int(SR*0.12),0.001,0.03); return x/np.abs(x).max()
def thud():
    d=0.35; tt=t(d); f=110*np.exp(-tt*9)+45; x=np.sin(2*np.pi*np.cumsum(f)/SR)*env(len(tt),0.001,0.09); return x/np.abs(x).max()
def buzz(d=0.45):
    tt=t(d); x=np.sign(np.sin(2*np.pi*140*tt))*0.6+np.sign(np.sin(2*np.pi*147*tt))*0.4; x*=np.minimum(1,np.minimum(tt/0.01,(d-tt)/0.05)); return x*0.6
def zap(d=0.5):
    tt=t(d); f=2400*np.exp(-tt*6)+180; x=np.sin(2*np.pi*np.cumsum(f)/SR)*(0.5+0.5*rng.standard_normal(len(tt))*0.3)*env(len(tt),0.001,0.15); return x/np.abs(x).max()
def sobe(d=0.8):
    tt=t(d); f=300*2**(tt*3); x=np.sin(2*np.pi*np.cumsum(f)/SR)*np.sin(np.pi*tt/d); return x/np.abs(x).max()

fx=np.zeros(N)
D=1.2  # tudo depois da abertura andou 1,2 s
def tecla():
    n=int(SR*0.03); x=rng.standard_normal(n)*env(n,0.0005,0.006); return x/np.abs(x).max()
# Cena 1 · busca digitada, lojas sendo pesquisadas, "cansado"
add(fx, whoosh(0.4), 0.45, 0.25)
for k in range(23): add(fx, tecla(), 0.8+k*(1.3/23)+rng.uniform(-0.01,0.01), 0.22)
for i in range(5): add(fx, pop(520+i*80), 1.6+i*0.32, 0.4)
add(fx, thud(), 3.7, 0.6); add(fx, buzz(0.5), 4.2, 0.3); add(fx, whoosh(), 4.45+D, 0.35)
# Cena 2
add(fx, whoosh(0.5), 4.85+D, 0.3)
for i in range(4): add(fx, notif(), 5.6+D+i*0.85, 0.55)
add(fx, whoosh(), 9.05+D, 0.35)
# Cena 3
for i in range(4):
    t0=9.4+D+i*2.05
    add(fx, whoosh(0.4), t0-0.05, 0.38); add(fx, notif(), t0+0.05, 0.45)
    add(fx, ding(1760,0.9), t0+0.4, 0.5); add(fx, thud(), t0+0.65, 0.5)
    if i<3: add(fx, whoosh(0.35,False), t0+1.72, 0.3)
# Cena 4
add(fx, zap(), 17.62+D, 0.5); add(fx, whoosh(), 21.65+D, 0.35)
# Cena 5
add(fx, sobe(), 22.0+D, 0.35); add(fx, pop(700), 23.2+D, 0.4); add(fx, pop(820), 23.35+D, 0.4)
add(fx, ding(2093,1.2), 25.4+D, 0.45); add(fx, pop(900), 25.45+D, 0.3)

# Trilha: 112 bpm, kick + chimbal + baixo + acorde suave (Am F C G)
mus=np.zeros(N); bpm=112; beat=60/bpm
def kick():
    d=0.3; tt=t(d); f=150*np.exp(-tt*25)+48; return np.sin(2*np.pi*np.cumsum(f)/SR)*env(len(tt),0.001,0.12)
def hat():
    n=int(SR*0.05); x=rng.standard_normal(n); x=np.diff(np.concatenate([[0],x]))*env(n,0.001,0.012); return x
acordes=[(220.0,261.6,329.6),(174.6,220.0,261.6),(130.8,164.8,196.0),(196.0,246.9,293.7)]
bars=int(DUR/(beat*4))+1
for b in range(bars):
    ch=acordes[b%4]; tb=b*beat*4
    if tb>=DUR: break
    d=beat*4; tt=t(d); pad=sum(np.sin(2*np.pi*f*tt)+0.3*np.sin(2*np.pi*2*f*tt) for f in ch)
    pad*=np.minimum(1,np.minimum(tt/0.3,(d-tt)/0.3)); add(mus, pad*0.05, tb)
    for k in range(4):
        tk=tb+k*beat
        add(mus, kick(), tk, 0.55)
        add(mus, hat(), tk+beat/2, 0.25)
        bass=np.sin(2*np.pi*ch[0]/2*t(beat*0.9))*env(int(SR*beat*0.9),0.005,0.25); add(mus, bass, tk, 0.22)
# Intro mais vazia e fade no fim
tt=np.arange(N)/SR
mus*=np.clip(tt/0.8,0,1)*np.clip((DUR-tt)/1.5,0,1)
mus/=np.abs(mus).max()
fx/=max(1,np.abs(fx).max())
mix=0.42*mus+0.75*fx
mix/=np.abs(mix).max()/0.89

def grava(nome, x):
    x=np.clip(x,-1,1); y=(x*32767).astype('<i2'); st=np.stack([y,y],1).ravel()
    w=wave.open(nome,'wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(st.tobytes()); w.close()
grava('efeitos-e-trilha.wav', mix)
grava('so-efeitos.wav', fx/np.abs(fx).max()*0.89)
grava('so-trilha.wav', mus*0.89)
print('ok')
